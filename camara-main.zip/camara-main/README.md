# camara
3.4. Configuración de la cámara: videojuego en 2D
